# BCHP - Phần mềm Quản lý Tiệm bánh Le Gaute

Ứng dụng WinForms (C#, .NET Framework 4.8) kết nối SQL Server.

## Cấu trúc thư mục

```
BCHP.sln
BCHP/
├── Program.cs          Điểm vào chương trình
├── App.config          Chuỗi kết nối CSDL (KetNoi)
├── Forms/              Các form giao diện (.cs + .Designer.cs + .resx)
│   ├── frmDangNhap
│   ├── frmDangKy
│   ├── frmMain
│   └── frmBanBanh
├── DAL/                Truy cập dữ liệu (DatabaseHelper, HoaDonDAL, CTHoaDonDAL)
├── Entities/           Các lớp thực thể (sẽ bổ sung)
├── Helpers/            Các hàm tiện ích (sẽ bổ sung)
└── Properties/
```

## Chạy thử

1. Mở `BCHP.sln` bằng Visual Studio 2019/2022.
2. Sửa `Data Source` trong `BCHP/App.config` cho đúng tên SQL Server của máy bạn.
3. Tạo CSDL `QL_LeGaute` (bảng `TaiKhoan`...) rồi nhấn F5.
