@echo off
echo Dang go chan cac file trong thu muc nay...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0.' -Recurse | Unblock-File"
echo Xong! Bay gio hay mo BCHP.sln trong Visual Studio.
pause
